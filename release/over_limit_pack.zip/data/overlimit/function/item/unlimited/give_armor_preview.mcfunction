function overlimit:item/unlimited/give_armor_royal
function overlimit:item/unlimited/give_armor_demon
